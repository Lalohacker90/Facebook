# cracking-password-facebook
script para hackear facebook por fuerza bruta!!!... necesita tener un diccionarios de datos y el correo de la victima
